/*
 * rfn9x.h
 *
 * Created: 9/16/2019 8:11:48 PM
 *  Author: Wesley
 */ 


#ifndef RFN9X_H_
#define RFN9X_H_

#include <stdbool.h>
#include <stdint.h>

void rfm9x_init();
bool rfm9x_send(const uint8_t *data, uint8_t length);

#endif /* RFN9X_H_ */
