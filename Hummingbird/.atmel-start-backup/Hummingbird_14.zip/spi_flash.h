/*
 * spi_flash.h
 *
 * Created: 11/23/2019 8:57:26 PM
 *  Author: Wesley
 */ 


#ifndef SPI_FLASH_H_
#define SPI_FLASH_H_


void spi_flash_init(void);


#endif /* SPI_FLASH_H_ */